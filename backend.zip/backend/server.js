const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const app = express();
const port = 5001;

app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/todoapp', {
  // useNewUrlParser: true,
  // useUnifiedTopology: true,
});

// User schema and model
const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
});
const User = mongoose.model('User', userSchema);

// Todo schema and model
const todoSchema = new mongoose.Schema({
  task: String,
  status: String,
  deadline: Date,
  userId: String,
});
const Todo = mongoose.model('Todo', todoSchema);

// Support message schema and model
const supportMessageSchema = new mongoose.Schema({
  name: String,
  email: String,
  message: String,
  date: { type: Date, default: Date.now },
});
const SupportMessage = mongoose.model('SupportMessage', supportMessageSchema);

// Middleware to check token
const authMiddleware = (req, res, next) => {
  const token = req.headers['authorization'];
  if (!token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  try {
    const decoded = jwt.verify(token.split(' ')[1], 'SECRET_KEY');
    req.userId = decoded.userId;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Unauthorized' });
  }
};

// Register API
app.post('/api/register', async (req, res) => {
  const { name, email, password } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ name, email, password: hashedPassword });
    await user.save();
    res.json({ message: 'User registered successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to register user' });
  }
});

// Login API
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ error: 'Invalid email or password' });
    }
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(400).json({ error: 'Invalid email or password' });
    }
    const token = jwt.sign({ userId: user._id }, 'SECRET_KEY');
    res.json({ token });
  } catch (error) {
    res.status(500).json({ error: 'Login failed' });
  }
});

// Get Todo List API
app.get('/api/getTodoList', authMiddleware, async (req, res) => {
  try {
    const todoList = await Todo.find({ userId: req.userId });
    res.json(todoList);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch todo list' });
  }
});

// Add Todo List API
app.post('/api/addTodoList', authMiddleware, async (req, res) => {
  const { task, status, deadline } = req.body;
  try {
    const todo = new Todo({
      task,
      status,
      deadline: new Date(deadline),
      userId: req.userId,
    });
    await todo.save();
    res.json({ message: 'Task added successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to add task' });
  }
});

// Update Todo List API
app.put('/api/updateTodoList/:id', authMiddleware, async (req, res) => {
  const { task, status, deadline } = req.body;
  try {
    const updatedTodo = await Todo.findByIdAndUpdate(req.params.id, { task, status, deadline: new Date(deadline) }, { new: true });
    if (!updatedTodo) {
      return res.status(404).json({ error: 'Todo not found' });
    }
    res.json({ message: 'Task updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update task' });
  }
});

// Delete Todo List API
app.delete('/api/deleteTodoList/:id', authMiddleware, async (req, res) => {
  try {
    await Todo.findByIdAndDelete(req.params.id);
    res.json({ message: 'Task deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete task' });
  }
});

// Support message API
app.post('/api/support', async (req, res) => {
  const { name, email, message } = req.body;
  try {
    const supportMessage = new SupportMessage({ name, email, message });
    await supportMessage.save();
    res.json({ message: 'Support message sent successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to send support message' });
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
