import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Todo() {
  const [todoList, setTodoList] = useState([]);
  const [editableId, setEditableId] = useState(null);
  const [editedTask, setEditedTask] = useState('');
  const [editedStatus, setEditedStatus] = useState('');
  const [newTask, setNewTask] = useState('');
  const [newStatus, setNewStatus] = useState('');
  const [newDeadline, setNewDeadline] = useState('');
  const [editedDeadline, setEditedDeadline] = useState('');

  useEffect(() => {
    fetchTodoList();
  }, []);

  const fetchTodoList = () => {
    const token = localStorage.getItem('token');
    axios.get('http://localhost:5001/api/getTodoList', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(result => setTodoList(result.data))
      .catch(err => console.log(err));
  };

  const toggleEditable = (id) => {
    const rowData = todoList.find((data) => data._id === id);
    if (rowData) {
      setEditableId(id);
      setEditedTask(rowData.task);
      setEditedStatus(rowData.status);
      setEditedDeadline(rowData.deadline ? new Date(rowData.deadline).toISOString().slice(0, 16) : '');
    } else {
      setEditableId(null);
      setEditedTask('');
      setEditedStatus('');
      setEditedDeadline('');
    }
  };

  const addTask = (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    axios.post('http://localhost:5001/api/addTodoList', {
      task: newTask,
      status: newStatus,
      deadline: newDeadline,
    }, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(res => {
        alert('Task added successfully');
        fetchTodoList();
        setNewTask('');
        setNewStatus('');
        setNewDeadline('');
      })
      .catch(err => alert('Failed to add task'));
  };

  const saveEditedTask = (id) => {
    const editedData = {
      task: editedTask,
      status: editedStatus,
      deadline: editedDeadline,
    };

    const token = localStorage.getItem('token');
    axios.put(`http://localhost:5001/api/updateTodoList/${id}`, editedData, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(result => {
        alert('Task updated successfully');
        fetchTodoList();
        setEditableId(null);
        setEditedTask('');
        setEditedStatus('');
        setEditedDeadline('');
      })
      .catch(err => alert('Failed to update task'));
  };

  const deleteTask = (id) => {
    const token = localStorage.getItem('token');
    axios.delete(`http://localhost:5001/api/deleteTodoList/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(result => {
        alert('Task deleted successfully');
        fetchTodoList();
      })
      .catch(err => alert('Failed to delete task'));
  };

  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col-md-7">
          <h2 className="text-center">Todo List</h2>
          <div className="table-responsive">
            <table className="table table-bordered">
              <thead className="table-primary">
                <tr>
                  <th>Task</th>
                  <th>Status</th>
                  <th>Deadline</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {todoList.length > 0 ? (
                  todoList.map((data) => (
                    <tr key={data._id}>
                      <td>
                        {editableId === data._id ? (
                          <input
                            type="text"
                            className="form-control"
                            value={editedTask}
                            onChange={(e) => setEditedTask(e.target.value)}
                          />
                        ) : (
                          data.task
                        )}
                      </td>
                      <td>
                        {editableId === data._id ? (
                          <input
                            type="text"
                            className="form-control"
                            value={editedStatus}
                            onChange={(e) => setEditedStatus(e.target.value)}
                          />
                        ) : (
                          data.status
                        )}
                      </td>
                      <td>
                        {editableId === data._id ? (
                          <input
                            type="datetime-local"
                            className="form-control"
                            value={editedDeadline}
                            onChange={(e) => setEditedDeadline(e.target.value)}
                          />
                        ) : (
                          new Date(data.deadline).toLocaleString()
                        )}
                      </td>
                      <td>
                        {editableId === data._id ? (
                          <button className="btn btn-success btn-sm" onClick={() => saveEditedTask(data._id)}>
                            Save
                          </button>
                        ) : (
                          <button className="btn btn-primary btn-sm" onClick={() => toggleEditable(data._id)}>
                            Edit
                          </button>
                        )}
                        <button className="btn btn-danger btn-sm ml-1" onClick={() => deleteTask(data._id)}>
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="4">No tasks found</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
        <div className="col-md-5">
          <h2 className="text-center">Add Task</h2>
          <form onSubmit={addTask}>
            <div className="form-group">
              <label>Task</label>
              <input
                type="text"
                className="form-control"
                value={newTask}
                onChange={(e) => setNewTask(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label>Status</label>
              <input
                type="text"
                className="form-control"
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label>Deadline</label>
              <input
                type="datetime-local"
                className="form-control"
                value={newDeadline}
                onChange={(e) => setNewDeadline(e.target.value)}
                required
              />
            </div>
            <button type="submit" className="btn btn-primary btn-block">
              Add Task
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Todo;
