import React from 'react';
import './About.css'; // Import the CSS file for styling

const About = () => {
  return (
    <div className="about-container">
      <h1>About Our To-Do App</h1>
      <img src={process.env.PUBLIC_URL + '/pic1.jpg'} alt="To-Do App" className="about-image" />
      <p>
        Welcome to our To-Do website! This application is designed to help you manage your daily tasks efficiently.
        With our app, you can add new tasks, update existing ones, and delete tasks that are no longer needed.
        You can also set deadlines for your tasks to stay on track with your schedule. Our goal is to help you
        stay organized and productive.
      </p>
    </div>
  );
};

export default About;
