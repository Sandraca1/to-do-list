import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';

const Login = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:5001/api/login', formData)
      .then(res => {
        localStorage.setItem('token', res.data.token);
        alert('Login successful');
        navigate('/todo');
      })
      .catch(err => {
        alert(err.response?.data?.error || 'Login failed');
      });
  };

  return (
    <div>
      <h2 align='center'>Login</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Email:</label>
          <input type="email" name="email" value={formData.email} onChange={handleChange} required />
        </div>
        <div>
          <label>Password:</label>
          <input type="password" name="password" value={formData.password} onChange={handleChange} required />
        </div>
        <button type="submit">Login</button>
      </form>
      <p align='center'>New user? <Link to="/register">Register here</Link></p>
    </div>
  );
};

export default Login;
